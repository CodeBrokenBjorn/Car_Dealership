module.exports = {
    HOST: "localhost",
    PORT: 3306,
    USER: "root",
    PASSOWRD: "",
    DB: "Cars_Tb",
    dialect: "mysql",
}